# Optional local 5M reproduction asset

`maia3-5m.onnx` is the exact Mobile Maia development-model export reused by the secondary 5M sampling experiment. It is preserved locally to reproduce that experiment; this task has not published or uploaded it externally.

- Original project: University of Toronto CSSLab, [CSSLab/maia3](https://github.com/CSSLab/maia3).
- Original model family/card: [UofTCSSLab/Maia3-5M](https://huggingface.co/UofTCSSLab/Maia3-5M).
- Pinned official source used for the app reference: `1e13597c42d4858b7cfd7cfdae01e297263364b2`.
- Export: 21,346,652 bytes, SHA-256 `ddae2aa893b5ca7ec94d24178871f1c337d09fd72ff38abe8d76b8ecf08cb942`.
- Local app copy: `pr41-review/build/unit_test_assets/assets/models/maia3-5m.onnx`, matching the app's `assets/models/maia3-5m.onnx` LFS oid. No retraining or model changes were made for this study.
- The original app conversion tool is included as `export_maia3_onnx.py`. Exact byte reproduction can depend on exporter/library versions; the included binary removes that requirement for the optional 5M experiment.

The [official source LICENSE at the pinned revision](https://github.com/CSSLab/maia3/blob/1e13597c42d4858b7cfd7cfdae01e297263364b2/LICENSE) is GNU Affero General Public License version 3 and is preserved in `UPSTREAM-LICENSE-AGPL-3.0.txt`. Mobile Maia's third-party notice identifies its converted Maia3 5M and 79M models with that licence and credits the University of Toronto CSSLab contributors. The upstream Hugging Face model card states CC BY 4.0 for the paper and points readers to the repository for the code/weights licence; it does not list a separate model-license tag. The exact card retrieved on 2 October 2026 is preserved as `UPSTREAM-MODEL-CARD.md`.

For attribution, the upstream model card cites Daniel Monroe, George Eilender, Philip Chalmers, Zhenwei Tang and Ashton Anderson, *Chessformer: A Unified Architecture for Chess Modeling*, ICLR 2026, [paper](https://openreview.net/forum?id=2ltBRzEHyd).

Current upstream model-card repository revision, retrieved separately for attribution, is `b6559de2398d7140b985f28fd2c19fb5e47ddabe`; its current original PyTorch checkpoint has SHA-256 `ba14208b2992d85502f5fb501934abf6aaaeb355e9f3fdf90e326911f562524f` and size 20,968,049 bytes. This current checkpoint metadata has not been independently proven to be the exact historical input to the preserved ONNX export, so it is not substituted for the study's ONNX pin.

For portable reproduction, set `MAIA5_MODEL` to this file's absolute path and run the portable `run_strength.py --model 5m --games-per-pair 200` command. The portable helper verifies the exact ONNX SHA-256 before inference. The primary 79M experiment does not depend on this optional asset and has a checked public download.
